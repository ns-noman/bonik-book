WPGear Edition. 08.03.2020
Adaptation for WordPress 5.7 with PHP 7.4

List of file changed:
	\PHPExcel\Shared\OLE.php
	\PHPExcel\Writer\Excel5\Worksheet.php
	\PHPExcel\Writer\Excel5\Workbook.php
	\PHPExcel\Writer\Excel5\Parser.php
	\PHPExcel\Cell\DefaultValueBinder.php
	\PHPExcel\Cell.php
	\PHPExcel\ReferenceHelper.php
	\PHPExcel\Worksheet\AutoFilter.php
	\PHPExcel\Calculation.php
	\PHPExcel\Shared\String.php
	
Deleted:
	\PHPExcel\Shared\PCLZip
	* This Lib already included to WP.